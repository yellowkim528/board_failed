package com.kh.board.web.req.reply;

import lombok.Data;

@Data
public class ResUpdate {
//  private String replyWriter;
  private String replyBody;
}
