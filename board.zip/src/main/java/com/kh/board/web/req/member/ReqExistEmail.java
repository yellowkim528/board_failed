package com.kh.board.web.req.member;

import lombok.Data;

@Data
public class ReqExistEmail {
  private String email;

}
