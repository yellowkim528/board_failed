package com.kh.board.web.form.members;

import lombok.Data;

@Data
public class LoginForm {
  private String email;
  private String passwd;
}
