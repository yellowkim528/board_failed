package com.kh.board.web.form.members;

public class SessionConst {
  public static final String LOGIN_MEMBER = "loginMember";

}
